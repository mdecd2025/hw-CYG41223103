# stand_controller.py
from controller import Robot, Keyboard, Emitter, DistanceSensor

# --- 常數與配置區 ---
TIME_STEP = 32 # ms

# 輪子控制參數
MAX_WHEEL_VELOCITY = 10.0 # 輪子最大速度 (rad/s)

# 感測器與計分參數
DISTANCE_SENSOR_NAME = 'sensor' # 距離感測器裝置名稱
SCORE_EMITTER_NAME = 'score_emitter' # 分數發射器裝置名稱
SCORE_INCREMENT = 2       # 每次得分增加的分數
SCORE_COOLDOWN_TIME = 1.0 # 每次得分後的冷卻時間（秒），防止重複計分
DISTANCE_THRESHOLD = 0.11 # 觸發得分的距離閾值 (公尺)

# 偵錯與訊息
DEBUG_DISTANCE_KEY = ord('F') 

# 距離感測器查找表 (AD值對應距離)
# 確保查找表是按照 AD 值遞減（距離遞增）的順序排列
LOOKUP_TABLE = [
    (1000, 0.00),
    (620, 0.12),
    (372, 0.13),
    (248, 0.14),
    (186, 0.15),
    (0, 0.18)
]

# --- 機器人控制器類別 ---
class StandController:
    """
    Webots Mecanum輪機器人控制器，處理移動、計分與訊息發送。
    """
    def __init__(self):
        # 初始化核心 Webots 物件
        self.robot = Robot()
        self.timestep = int(self.robot.getBasicTimeStep())
        self.keyboard = Keyboard()
        self.keyboard.enable(self.timestep)

        # --- 裝置初始化 ---
        self.emitter = self._get_and_enable_device(SCORE_EMITTER_NAME, Emitter)
        self.distance_sensor = self._get_and_enable_device(DISTANCE_SENSOR_NAME, DistanceSensor)
        self.wheels = self._init_wheels()

        # --- 計分相關狀態 ---
        self.current_robot_score = 0 # 這個分數是機器人內部自己計算的，非最終顯示在七段顯示器上的總分
        self.last_score_time = 0.0 # 上次得分的時間點

        # --- 啟動訊息 ---
        self._print_startup_info()

    def _get_and_enable_device(self, device_name, device_type):
        """
        嘗試獲取並啟用指定的裝置，如果失敗則打印錯誤訊息並返回 None。
        """
        try:
            device = self.robot.getDevice(device_name)
            if device:
                if hasattr(device, 'enable'): # 檢查裝置是否有 enable 方法
                    device.enable(self.timestep)
                print(f"Mecanum 輪控制器：裝置 '{device_name}' ({device_type.__name__}) 已成功啟用。")
                return device
            else:
                print(f"錯誤: Mecanum 輪控制器：找不到裝置 '{device_name}'。")
                return None
        except Exception as e:
            print(f"錯誤: Mecanum 輪控制器：無法初始化裝置 '{device_name}' ({device_type.__name__}): {e}")
            return None

    def _init_wheels(self):
        """初始化並設定 Mecanum 輪裝置。"""
        wheel_names = ["wheel5", "wheel6", "wheel7", "wheel8"] # Mecanum 輪命名
        wheels_dict = {}
        all_wheels_found = True
        for name in wheel_names:
            try:
                wheel = self.robot.getDevice(name)
                if wheel:
                    wheel.setPosition(float('inf'))  # 啟用速度控制模式
                    wheel.setVelocity(0)             # 初始速度設為 0
                    wheels_dict[name] = wheel
                else:
                    print(f"錯誤: Mecanum 輪控制器：找不到 Mecanum 輪裝置 '{name}'。")
                    all_wheels_found = False
            except Exception as e:
                print(f"錯誤: Mecanum 輪控制器：無法初始化 Mecanum 輪裝置 '{name}': {e}")
                all_wheels_found = False
        
        if not all_wheels_found:
            print("警告: Mecanum 輪控制器：部分或所有 Mecanum 輪裝置未找到，移動功能可能受限或無法使用。")
        return wheels_dict

    def _print_startup_info(self):
        """打印啟動時的控制說明。"""
        print("\n--- Mecanum 輪機器人控制器已啟動 ---")
        print("移動控制:")
        print("  按 'W' (或 'w') : 向前移動")
        print("  按 'S' (或 's') : 向後移動")
        print("  按 'D' (或 'd') : 向右橫移") # Mecanum 輪 D 為右橫移
        print("  按 'A' (或 'a') : 向左橫移") # Mecanum 輪 A 為左橫移
        print("感測器偵錯:")
        print(f"  按 '{chr(DEBUG_DISTANCE_KEY).upper()}' (或 '{chr(DEBUG_DISTANCE_KEY).lower()}') : 顯示感測器距離")
        print("退出:")
        print("  按 'ESC' : 退出模擬 (此控制器專用退出鍵)")
        print("-" * 30)

    def _set_mecanum_wheel_velocities(self, v_fr, v_fl, v_rr, v_rl):
        """
        設定 Mecanum 輪的速度。
        輪子順序: wheel5: 前右 (FR), wheel6: 前左 (FL), wheel7: 後右 (RR), wheel8: 後左 (RL)
        """
        if len(self.wheels) == 4: # 確保所有輪子都已初始化
            self.wheels["wheel5"].setVelocity(v_fr) # FR
            self.wheels["wheel6"].setVelocity(v_fl) # FL
            self.wheels["wheel7"].setVelocity(v_rr) # RR
            self.wheels["wheel8"].setVelocity(v_rl) # RL
        else:
            pass # 警告已在初始化時打印

    def _handle_keyboard_input(self, key):
        """根據鍵盤輸入控制機器人移動。"""
        # 預設停止所有輪子
        self._set_mecanum_wheel_velocities(0, 0, 0, 0)

        # 移動控制：WASD 
        if key == ord('W') or key == ord('w'): # 前進
            self._set_mecanum_wheel_velocities(MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY)
        elif key == ord('S') or key == ord('s'): # 後退
            self._set_mecanum_wheel_velocities(-MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY)
        elif key == ord('D') or key == ord('d'): # 右橫移 (Mecanum 輪特有)
            # Mecanum wheel kinematics for right strafe
            self._set_mecanum_wheel_velocities(-MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY)
        elif key == ord('A') or key == ord('a'): # 左橫移 (Mecanum 輪特有)
            # Mecanum wheel kinematics for left strafe
            self._set_mecanum_wheel_velocities(MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY, -MAX_WHEEL_VELOCITY, MAX_WHEEL_VELOCITY)
        
        # 感測器偵錯輸出 (新鍵 F)
        elif key == DEBUG_DISTANCE_KEY:
            if self.distance_sensor:
                sensor_value = self.distance_sensor.getValue()
                distance = self._ad_to_distance(sensor_value)
                print(f"Mecanum 輪感測器 AD 值: {sensor_value}, 換算距離: {distance:.3f} 公尺")

        # 退出機制 (ESC 鍵通用於所有控制器)
        elif key == 27: # Modified: Replaced Keyboard.ESCAPE with 27
            print("Mecanum 輪控制器：偵測到 'ESC' 鍵，正在退出模擬。")
            return True # 返回 True 表示應退出主循環

        return False # 返回 False 表示不退出

    def _ad_to_distance(self, ad_value):
        """
        將距離感測器的 AD 值轉換為實際距離（公尺），使用線性插值。
        假設 LOOKUP_TABLE 的 AD 值是遞減排列的。
        """
        if ad_value >= LOOKUP_TABLE[0][0]:
            return LOOKUP_TABLE[0][1]
        if ad_value <= LOOKUP_TABLE[-1][0]:
            return LOOKUP_TABLE[-1][1]

        for i in range(len(LOOKUP_TABLE) - 1):
            ad0, dist0 = LOOKUP_TABLE[i]
            ad1, dist1 = LOOKUP_TABLE[i+1]
            
            if ad1 <= ad_value <= ad0:
                if (ad1 - ad0) == 0: 
                    return dist0
                ratio = (ad_value - ad0) / (ad1 - ad0)
                return dist0 + (dist1 - dist0) * ratio
        return LOOKUP_TABLE[-1][1]

    def _check_and_send_score(self):
        """
        檢查是否滿足計分條件，如果滿足則計分並發送。
        包含冷卻時間，防止重複計分。
        """
        if not self.distance_sensor or not self.emitter:
            return 

        current_time = self.robot.getTime()
        
        if (current_time - self.last_score_time) > SCORE_COOLDOWN_TIME:
            sensor_value = self.distance_sensor.getValue()
            distance = self._ad_to_distance(sensor_value)

            if distance < DISTANCE_THRESHOLD:
                self.current_robot_score += SCORE_INCREMENT
                print(f"Mecanum 輪機器人得分！當前內部總分: {self.current_robot_score}。偵測距離: {distance:.3f} 公尺。")
                
                # 發送得分訊息給 Supervisor
                self.emitter.send(str(SCORE_INCREMENT).encode('utf-8'))
                
                self.last_score_time = current_time 

    def run(self):
        """
        機器人的主模擬循環。
        """
        while self.robot.step(self.timestep) != -1:
            key = self.keyboard.getKey()
            
            if self._handle_keyboard_input(key):
                break 

            self._check_and_send_score()

# --- 腳本執行入口點 ---
if __name__ == "__main__":
    controller = StandController()
    controller.run()
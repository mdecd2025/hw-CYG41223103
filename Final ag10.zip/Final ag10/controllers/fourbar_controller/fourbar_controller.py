# fourbar_controller.py
from controller import Robot, Keyboard

# Constants
TIME_STEP = 32
YOUBOT_MAX_VELOCITY = 10.0 # YouBot 輪子最大速度

# YouBot 機構控制參數 (單軸馬達)
YOUBOT_MECHANISM_ANGLE_M = 40 * 3.14159 / 180  # +40 degrees in radians (for 'M' key)
YOUBOT_MECHANISM_ANGLE_K = 0.0                 # 0 degrees (for 'K' key) - 這是原位

# 鍵盤防抖 (防止按鍵持續觸發)
YOUBOT_KEY_DEBOUNCE_TIME = 0.2 

class YouBotController:
    def __init__(self):
        self.robot = Robot()
        self.timestep = int(self.robot.getBasicTimeStep())
        self.keyboard = Keyboard()
        self.keyboard.enable(self.timestep)

        # --- YouBot 輪子裝置 ---
        self.youbot_wheels = []
        self.youbot_platform_enabled = False
        try:
            for i in range(4):
                wheel = self.robot.getDevice(f"wheel{i+1}")
                if wheel:
                    wheel.setPosition(float('inf'))  # 無限位置，速度控制模式
                    wheel.setVelocity(0)             # 初始速度為 0
                    self.youbot_wheels.append(wheel)
                else:
                    print(f"錯誤: YouBot 控制器：找不到 YouBot 車輪裝置 'wheel{i+1}'。")
            if len(self.youbot_wheels) == 4:
                self.youbot_platform_enabled = True
                print("YouBot 控制器：四個車輪裝置已成功啟用。")
            else:
                print("警告: YouBot 控制器：部分 YouBot 車輪裝置未找到，YouBot 移動功能可能受限。")
        except Exception as e:
            print(f"錯誤: YouBot 控制器：無法初始化 YouBot 車輪裝置: {e}。YouBot 移動控制已禁用。")

        # --- YouBot 機構裝置 ---
        self.youbot_motor = None
        self.youbot_sensor = None
        self.youbot_mechanism_enabled = False
        try:
            self.youbot_motor = self.robot.getDevice('motor1') # 假設機構馬達名稱為 'motor1'
            self.youbot_sensor = self.robot.getDevice('motor1_sensor') # 假設機構感測器名稱為 'motor1_sensor'
            if self.youbot_motor and self.youbot_sensor:
                self.youbot_sensor.enable(self.timestep)
                self.youbot_mechanism_enabled = True
                # 將機構馬達設置為初始位置 (0度)，確保一開始就在原位
                self.youbot_motor.setPosition(YOUBOT_MECHANISM_ANGLE_K)
                print(f"YouBot 控制器：機構馬達 'motor1' 和感測器已成功啟用，並設置初始位置為 {YOUBOT_MECHANISM_ANGLE_K:.2f} 弧度。")
            else:
                print("警告: YouBot 控制器：找到馬達但找不到感測器，或反之。機構功能可能受限。")
        except Exception as e:
            print(f"錯誤: YouBot 控制器：無法找到 'motor1' 或其感測器 ({e})。YouBot 機構控制已禁用。")

        # YouBot 機構狀態機：控制按鍵觸發順序
        # 初始狀態為 "idle"，允許 M 或 K 鍵從任何位置開始。
        # 一旦 M 或 K 被按下，則切換到對應的 "allow_other_key" 狀態。
        self.youbot_current_mechanism_state = "initial_k" # 初始為 K 鍵位置，但允許 M 鍵觸發

        # YouBot 按鍵防抖狀態
        self.youbot_key_pressed_m = False
        self.youbot_key_pressed_k = False
        self.last_youbot_key_time = 0.0 # 用於 YouBot 的按鍵防抖

        self._print_startup_info()

    def _print_startup_info(self):
        """打印啟動時的控制說明。"""
        print("\n--- YouBot 機器人控制器已啟動 ---")
        print("YouBot 移動控制:")
        print("  按 '上箭頭' : 向前移動")
        print("  按 '下箭頭' : 向後移動")
        print("  按 '左箭頭' : 向左轉向")
        print("  按 '右箭頭' : 向右轉向")
        print("YouBot 機構控制:")
        print("  按 'M' (或 'm') : 激活機構位置 (+40度)")
        print("  按 'K' (或 'k') : 激活機構位置 (0度，歸位)")
        print("退出:")
        print("  按 'ESC' : 退出模擬 (此控制器專用退出鍵)")
        print("-" * 30)

    def _set_youbot_wheel_velocities(self, v_fr, v_fl, v_rr, v_rl):
        """設定 YouBot 四個輪子的速度 (前右, 前左, 後右, 後左)。"""
        if self.youbot_platform_enabled and len(self.youbot_wheels) == 4:
            self.youbot_wheels[0].setVelocity(v_fr) # 通常 wheel1
            self.youbot_wheels[1].setVelocity(v_fl) # 通常 wheel2
            self.youbot_wheels[2].setVelocity(v_rr) # 通常 wheel3
            self.youbot_wheels[3].setVelocity(v_rl) # 通常 wheel4
        else:
            pass # 警告已在初始化時打印

    def _handle_keyboard_input(self, key):
        """處理 YouBot 的鍵盤輸入，包括移動和機構控制。"""
        # 預設停止所有輪子
        self._set_youbot_wheel_velocities(0, 0, 0, 0)

        # 處理 YouBot 平台移動 (箭頭鍵)
        if key == Keyboard.UP: # YouBot 前進
            self._set_youbot_wheel_velocities(YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY)
        elif key == Keyboard.DOWN: # YouBot 後退
            self._set_youbot_wheel_velocities(-YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY)
        elif key == Keyboard.RIGHT: # YouBot 右轉 (原地轉向)
            self._set_youbot_wheel_velocities(-YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY)
        elif key == Keyboard.LEFT: # YouBot 左轉 (原地轉向)
            self._set_youbot_wheel_velocities(YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY, YOUBOT_MAX_VELOCITY, -YOUBOT_MAX_VELOCITY)

        # 處理 YouBot 機構控制 (M/K 鍵)
        if self.youbot_mechanism_enabled:
            current_time = self.robot.getTime()
            
            # M key: 投籃姿勢
            if key == ord('M') or key == ord('m'):
                if not self.youbot_key_pressed_m and \
                   (current_time - self.last_youbot_key_time) > YOUBOT_KEY_DEBOUNCE_TIME:
                    # 只有當前不是處於 M 狀態，或者 K 鍵已觸發過時才執行
                    if self.youbot_current_mechanism_state != "at_m_pos":
                        self.youbot_motor.setPosition(YOUBOT_MECHANISM_ANGLE_M)
                        self.youbot_current_mechanism_state = "at_m_pos"
                        self.last_youbot_key_time = current_time
                self.youbot_key_pressed_m = True
            else:
                self.youbot_key_pressed_m = False

            # K key: 歸位姿勢
            if key == ord('K') or key == ord('k'):
                if not self.youbot_key_pressed_k and \
                   (current_time - self.last_youbot_key_time) > YOUBOT_KEY_DEBOUNCE_TIME:
                    # 只有當前不是處於 K 狀態，或者 M 鍵已觸發過時才執行
                    if self.youbot_current_mechanism_state != "at_k_pos":
                        self.youbot_motor.setPosition(YOUBOT_MECHANISM_ANGLE_K)
                        self.youbot_current_mechanism_state = "at_k_pos"
                        self.last_youbot_key_time = current_time
                self.youbot_key_pressed_k = True
            else:
                self.youbot_key_pressed_k = False
        
        # 退出機制 (ESC 鍵通用於所有控制器)
        if key == 27: # Modified: Replaced Keyboard.ESCAPE with 27
            print("YouBot 控制器：偵測到 'ESC' 鍵，正在退出模擬。")
            return True # 返回 True 表示應退出主循環
        
        return False # 返回 False 表示不退出

    def run(self):
        """YouBot 機器人的主模擬循環。"""
        while self.robot.step(self.timestep) != -1:
            key = self.keyboard.getKey()
            
            if self._handle_keyboard_input(key):
                break

# --- 腳本執行入口點 ---
if __name__ == "__main__":
    controller = YouBotController()
    controller.run()
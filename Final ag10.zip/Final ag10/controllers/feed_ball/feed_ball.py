# feed_ball.py
from controller import Supervisor, Keyboard
import time
import random
import numpy as np
import re

# ----------------- 參數區 -----------------
# 注意：HOOP_CENTER_RESET_POS 應該是一個固定的世界座標，如果用於 R 鍵回歸，需確保其正確。
# 這裡使用一個合理的預設值，請根據你的世界中的實際籃框中心調整。
# 假設的籃框中心位置，請依你的實際模型調整
HOOP_CENTER_RESET_POS = [0.622, -0.103, 0.742838]
BALL_RADIUS = 0.1
BALL_MASS = 0.01

TRAJECTORY_POINT_RADIUS = 0.03      # 軌跡小球半徑
TRAJECTORY_POINT_MIN_DISTANCE = 0.12 # 軌跡點間最小距離
TRAJECTORY_MAX_POINTS = 5           # 最多保留的軌跡點數量
TRAJECTORY_POINT_COLOR = [1, 0.7, 0] # 軌跡點顏色 (橘色)
TRAJECTORY_POINT_TRANSPARENCY = 0.3
BALL_LANDED_THRESHOLD_Z = 0.13 # 球被視為落地的Z座標閾值 (Z軸高度)

# 預設的球生成位置 (相對於 YouBot)
DEFAULT_BALL_FEED_POS_LOCAL_YOUBOT = (-0.35, 0.0, 0.9)

supervisor = Supervisor()
timestep = int(supervisor.getBasicTimeStep())
keyboard = Keyboard()
keyboard.enable(timestep)

waiting_ball_def = None        # 當前靜止球的 DEF 名稱
waiting_ball_info = None       # 當前靜止球的詳細資訊 (位置, 顏色)
current_tracked_ball_def = None # 當前正在追蹤的動態球的 DEF 名稱
trajectory_points = []         # 儲存軌跡點的 (位置, DEF名稱) 元組列表

last_key_time_q = 0.0 # 為Q鍵設置獨立防抖時間
last_key_time_m = 0.0 # 為M鍵設置獨立防抖時間 (發射)
last_key_time_r = 0.0 # 為R鍵設置獨立防抖時間
SUPERVISOR_KEY_DEBOUNCE_TIME = 0.5 # Supervisor 鍵盤防抖時間

# --- 全局快取 ---
_youbot_node_cache = None
_root_node_cache = None
_children_field_cache = None

def _get_youbot_node():
    global _youbot_node_cache
    if _youbot_node_cache is None:
        _youbot_node_cache = supervisor.getFromDef('youbot')
        if not _youbot_node_cache:
            print("警告：籃球控制器：找不到 DEF 為 'youbot' 的 Robot 物件。籃球生成將預設在世界原點附近。")
    return _youbot_node_cache

def _get_root_node_children_field():
    global _root_node_cache, _children_field_cache
    if _root_node_cache is None:
        _root_node_cache = supervisor.getRoot()
    if _children_field_cache is None and _root_node_cache:
        _children_field_cache = _root_node_cache.getField("children")
    return _children_field_cache

def _axis_angle_to_rotation_matrix(axis, angle):
    """將軸角表示轉換為旋轉矩陣。"""
    x, y, z = axis
    c = np.cos(angle)
    s = np.sin(angle)
    C = 1 - c
    return np.array([
        [x*x*C + c,     x*y*C - z*s, x*z*C + y*s],
        [y*x*C + z*s, y*y*C + c,     y*z*C - x*s],
        [z*x*C - y*s, z*y*C + x*s, z*z*C + c]
    ])

def _youbot_local_to_world(local_pos):
    """將 YouBot 局部座標轉換為世界座標。"""
    youbot_node = _get_youbot_node()
    if not youbot_node:
        return (0.0, 0.0, 1.0) # 預設在世界原點上方
    try:
        youbot_translation = np.array(youbot_node.getField('translation').getSFVec3f())
        youbot_rotation = youbot_node.getField('rotation').getSFRotation()
        youbot_axis = youbot_rotation[:3]
        youbot_angle = youbot_rotation[3]
        youbot_rot_mat = _axis_angle_to_rotation_matrix(youbot_axis, youbot_angle)

        rotated_local_pos = youbot_rot_mat @ np.array(local_pos)
        world_pos = youbot_translation + rotated_local_pos
        return tuple(world_pos)
    except Exception as e:
        print(f"錯誤：籃球控制器：轉換 YouBot 局部座標到世界座標失敗: {e}")
        return (0.0, 0.0, 1.0) # 失敗時也返回一個預設位置

def _generate_unique_def_name(base_name="Object"):
    """生成一個唯一的 DEF 名稱"""
    return f"{base_name}_{int(supervisor.getTime() * 1000)}_{random.randint(0, 99999)}"

def _generate_random_color():
    """生成一個隨機的 RGB 顏色元組"""
    return (random.random(), random.random(), random.random())

def _create_sphere_node(def_name, world_pos, color_rgb, is_dynamic=False):
    """
    創建一個球體的 WBT 字串並插入到場景中。
    可選擇創建靜態 (Transform) 或動態 (Solid with Physics) 球。
    """
    children_field = _get_root_node_children_field()
    if not children_field:
        print("錯誤：籃球控制器：無法獲取根節點的 children 欄位，無法創建球體。")
        return

    sphere_string = f"""
    DEF {def_name} Solid {{
      translation {world_pos[0]} {world_pos[1]} {world_pos[2]}
      contactMaterial "ball"
      children [
        Shape {{
          geometry Sphere {{
            radius {BALL_RADIUS}
          }}
          appearance Appearance {{
            material Material {{
              diffuseColor {color_rgb[0]} {color_rgb[1]} {color_rgb[2]}
            }}
          }}
        }}
      ]
      boundingObject Sphere {{
        radius {BALL_RADIUS}
      }}
      {"physics Physics {{ mass {} density -1 }}".format(BALL_MASS) if is_dynamic else ""}
    }}
    """
    try:
        children_field.importMFNodeFromString(-1, sphere_string)
    except Exception as e:
        print(f"錯誤：籃球控制器：無法創建球體節點 {def_name}：{e}")

def create_static_basketball(local_pos_in_youbot):
    """在 YouBot 的局部座標創建一個靜止的籃球。"""
    global waiting_ball_def, waiting_ball_info, current_tracked_ball_def
    if waiting_ball_def is not None:
        print("籃球控制器：還有一顆球等待處理，請先發射或回歸再產生新球。")
        return

    def_name = _generate_unique_def_name("Basketball")
    rgb = _generate_random_color()
    world_pos = _youbot_local_to_world(local_pos_in_youbot)

    _create_sphere_node(def_name, world_pos, rgb, is_dynamic=False)

    waiting_ball_def = def_name
    waiting_ball_info = (world_pos, rgb)
    current_tracked_ball_def = def_name # 新球產生時開始追蹤
    _delete_all_trajectory_points() # 新球產生時清除舊軌跡
    print(f"籃球控制器：靜止籃球 '{def_name}' 已在 YouBot 前方生成。")

def activate_basketball_dynamic():
    """將當前靜止的籃球轉換為動態球。"""
    global waiting_ball_def, waiting_ball_info, current_tracked_ball_def
    if waiting_ball_def is None:
        print("籃球控制器：沒有靜止的球可以激活。")
        return
    
    # 確保要激活的是當前等待的球
    if current_tracked_ball_def != waiting_ball_def:
        print("警告：籃球控制器：嘗試激活的球不是當前等待的球。")
        return

    ball_node_to_remove = supervisor.getFromDef(waiting_ball_def)
    if ball_node_to_remove:
        ball_node_to_remove.remove()
        supervisor.step(int(supervisor.getBasicTimeStep())) # 必須執行一步，讓Webots處理節點移除
    else:
        print(f"警告：籃球控制器：嘗試激活的球 '{waiting_ball_def}' 不存在於場景中。")
        waiting_ball_def = None # 防止無限循環嘗試移除不存在的球
        waiting_ball_info = None
        current_tracked_ball_def = None
        return

    world_pos, rgb = waiting_ball_info
    _create_sphere_node(waiting_ball_def, world_pos, rgb, is_dynamic=True)

    print(f"籃球控制器：靜止籃球 '{waiting_ball_def}' 已被激活。")
    waiting_ball_def = None # 激活後不再是等待狀態
    waiting_ball_info = None

def reset_ball_to_origin():
    """刪除當前所有球體並在指定位置生成一顆新的靜止球。"""
    global waiting_ball_def, waiting_ball_info, current_tracked_ball_def
    
    # 刪除所有可能的舊球體 (無論靜止或動態)
    if current_tracked_ball_def:
        node = supervisor.getFromDef(current_tracked_ball_def)
        if node:
            node.remove()
            # 確保 Webots 有時間處理移除
            supervisor.step(int(supervisor.getBasicTimeStep()))
        current_tracked_ball_def = None
    
    # 如果等待中的球還存在，也刪除它
    if waiting_ball_def:
        node = supervisor.getFromDef(waiting_ball_def)
        if node:
            node.remove()
            supervisor.step(int(supervisor.getBasicTimeStep()))
        waiting_ball_def = None
        waiting_ball_info = None
    
    _delete_all_trajectory_points() # 清除所有軌跡點

    # 在預設位置生成一顆新的靜止球
    def_name = _generate_unique_def_name("Basketball")
    rgb = _generate_random_color()
    
    _create_sphere_node(def_name, HOOP_CENTER_RESET_POS, rgb, is_dynamic=False) # 在籃框中心生成
    
    waiting_ball_def = def_name
    waiting_ball_info = (HOOP_CENTER_RESET_POS, rgb)
    current_tracked_ball_def = def_name # 開始追蹤新生成的球
    print(f"籃球控制器：所有球體已重置並在籃框中心生成新的靜止球 '{def_name}'。")


def _create_trajectory_point(pos):
    """在指定位置創建一個小球作為視覺軌跡點。"""
    children_field = _get_root_node_children_field()
    if not children_field:
        print("錯誤：籃球控制器：無法獲取根節點的 children 欄位，無法創建軌跡點。")
        return None

    def_name = _generate_unique_def_name("TrajectoryPt")
    point_string = f"""
    DEF {def_name} Transform {{
      translation {pos[0]} {pos[1]} {pos[2]}
      children [
        Shape {{
          geometry Sphere {{
            radius {TRAJECTORY_POINT_RADIUS}
          }}
          appearance Appearance {{
            material Material {{
              diffuseColor {TRAJECTORY_POINT_COLOR[0]} {TRAJECTORY_POINT_COLOR[1]} {TRAJECTORY_POINT_COLOR[2]}
              transparency {TRAJECTORY_POINT_TRANSPARENCY}
            }}
          }}
        }}
      ]
    }}
    """
    try:
        children_field.importMFNodeFromString(-1, point_string)
        return def_name
    except Exception as e:
        print(f"錯誤：籃球控制器：無法創建軌跡點 {def_name}：{e}")
        return None

def _delete_all_trajectory_points():
    """刪除所有已創建的軌跡點。"""
    global trajectory_points
    for _, def_name in trajectory_points:
        node = supervisor.getFromDef(def_name)
        if node:
            node.remove()
            supervisor.step(int(supervisor.getBasicTimeStep())) # 確保 Webots 有時間處理移除
    trajectory_points.clear()

def _is_ball_landed(pos):
    """判斷球是否落地 (z 座標低於閾值)。"""
    return pos[2] < BALL_LANDED_THRESHOLD_Z

def update_trajectory():
    """更新軌跡點列表，新增點並移除舊點以維持數量限制。"""
    global current_tracked_ball_def, waiting_ball_def, waiting_ball_info
    if current_tracked_ball_def:
        ball_node = supervisor.getFromDef(current_tracked_ball_def)
        if ball_node:
            pos = ball_node.getPosition()
            # 只有當距離上次軌跡點足夠遠時才新增
            if (not trajectory_points) or \
               np.linalg.norm(np.array(pos) - np.array(trajectory_points[-1][0])) > TRAJECTORY_POINT_MIN_DISTANCE:
                
                new_point_def = _create_trajectory_point(pos)
                if new_point_def:
                    trajectory_points.append((pos, new_point_def))
                    while len(trajectory_points) > TRAJECTORY_MAX_POINTS:
                        _, old_def = trajectory_points.pop(0)
                        node_to_remove = supervisor.getFromDef(old_def)
                        if node_to_remove:
                            node_to_remove.remove()
            
            # 檢查球是否落地
            if _is_ball_landed(pos):
                print(f"籃球控制器：球 '{current_tracked_ball_def}' 已落地，清除軌跡並停止追蹤。")
                _delete_all_trajectory_points()
                
                # 如果是當前追蹤的球落地，才停止追蹤
                if current_tracked_ball_def:
                    node = supervisor.getFromDef(current_tracked_ball_def)
                    if node:
                        node.remove() # 刪除已落地的球
                        supervisor.step(int(supervisor.getBasicTimeStep()))
                current_tracked_ball_def = None 
                # 如果是等待狀態的球落地，也應該清除其狀態
                if waiting_ball_def: # 如果有球正在等待，並且它就是剛剛落地的球
                    waiting_ball_def = None
                    waiting_ball_info = None
        else:
            # 如果追蹤的球節點消失，則停止追蹤並清除軌跡
            if current_tracked_ball_def is not None:
                print(f"籃球控制器：追蹤的球 '{current_tracked_ball_def}' 已不存在，清除軌跡並停止追蹤。")
                _delete_all_trajectory_points()
                current_tracked_ball_def = None


print("--- 籃球生成/追蹤 Supervisor 控制器已啟動 ---")
print("籃球控制器鍵盤控制:")
print("  按 'Q' (或 'q') : 生成靜止籃球 (位於 YouBot 機器人前)")
print("  按 'M' (或 'm') : 激活靜止籃球 (使其動態化可擊出)")
print("  按 'R' (或 'r') : 回歸原位 (刪除所有球並在籃框中心生成新靜止球)")
print("  按 'ESC' : 退出模擬 (此控制器專用退出鍵)")
print("注意：只有一顆球會被追踪軌跡，且球落地後軌跡自動消失。")
print("-" * 30)

while supervisor.step(timestep) != -1:
    key = keyboard.getKey()
    current_time = supervisor.getTime()

    # 處理鍵盤輸入，加入防抖
    if key == ord('Q') or key == ord('q'): # 生成球體
        if (current_time - last_key_time_q) >= SUPERVISOR_KEY_DEBOUNCE_TIME:
            create_static_basketball(DEFAULT_BALL_FEED_POS_LOCAL_YOUBOT)
            last_key_time_q = current_time
    elif key == ord('M') or key == ord('m'): # 發射球體 (激活)
        if (current_time - last_key_time_m) >= SUPERVISOR_KEY_DEBOUNCE_TIME: 
            activate_basketball_dynamic()
            last_key_time_m = current_time
    elif key == ord('R') or key == ord('r'): # 回歸原位
        if (current_time - last_key_time_r) >= SUPERVISOR_KEY_DEBOUNCE_TIME:
            reset_ball_to_origin()
            last_key_time_r = current_time
    elif key == 27: # Modified: Replaced Keyboard.ESCAPE with 27
        print("籃球控制器：偵測到 'ESC' 鍵，正在退出模擬。")
        break
    
    # 更新籃球軌跡
    update_trajectory()
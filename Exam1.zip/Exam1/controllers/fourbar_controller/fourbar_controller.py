from controller import Robot

def run_robot():

    robot = Robot()

    timestep = int(robot.getBasicTimeStep())

    motor = robot.getDevice('motor') 

    motor.setPosition(float('inf')) 
    
    motor.setVelocity(1.0)          
    
    print(f"✅啟動裝置")


    while robot.step(timestep) != -1: 
        
        pass

if __name__ == "__main__":

    run_robot()

